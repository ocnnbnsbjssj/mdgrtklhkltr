import React, { useState, useEffect } from 'react';
import { Send, Paperclip, ChevronDown, Menu, Settings, Key } from 'lucide-react';
import { cn } from './lib/utils';
import { models, sendMessage, type ModelConfig } from './lib/api';
import { encryptApiKey, decryptApiKey } from './lib/encryption';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

type Section = 'astro' | 'compatibility' | 'interpretation' | 'political' | 'spiritual' | 'horoscope' | 'chat';

const sections = {
  astro: 'تحليل الصور الفلكية',
  compatibility: 'توافق الشريك والطلاسم',
  interpretation: 'التفسير',
  political: 'التوقعات السياسية',
  spiritual: 'الروحانية',
  horoscope: 'الأبراج وحركة الكواكب',
  chat: 'الشات الرئيسي'
};

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [selectedModel, setSelectedModel] = useState<ModelConfig>(models[0]);
  const [apiKey, setApiKey] = useState('');
  const [currentSection, setCurrentSection] = useState<Section>('chat');
  const [showDropdown, setShowDropdown] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
    // Load saved API key on component mount
    const savedKey = localStorage.getItem(`apiKey_${selectedModel.id}`);
    if (savedKey) {
      const decrypted = decryptApiKey(savedKey);
      setApiKey(decrypted);
    }
  }, [selectedModel]);

  const handleSend = async () => {
    if (!input.trim() || !apiKey) return;

    const newMessages = [
      ...messages,
      { role: 'user', content: input }
    ];
    setMessages(newMessages);
    setInput('');

    try {
      const response = await sendMessage(selectedModel.model, apiKey, input);
      setMessages([
        ...newMessages,
        { role: 'assistant', content: response }
      ]);
    } catch (error) {
      alert('حدث خطأ في الاتصال بالخادم');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const saveApiKey = () => {
    const encrypted = encryptApiKey(apiKey);
    localStorage.setItem(`apiKey_${selectedModel.id}`, encrypted);
    setShowSettings(false);
    alert('✅ تم حفظ API Key بنجاح!');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-white p-4" dir="rtl">
      <div className="max-w-4xl mx-auto">
        {/* Header with Dropdowns */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-bold text-center flex items-center gap-2">
            <span className="text-3xl">🔮</span>
            العراف - {sections[currentSection]}
          </h1>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="bg-gray-700 hover:bg-gray-600 rounded-lg p-2"
              title="إعدادات النموذج"
            >
              <Settings size={20} />
            </button>
            <div className="relative">
              <button
                onClick={() => setShowDropdown(!showDropdown)}
                className="bg-gray-700 hover:bg-gray-600 rounded-lg p-2 flex items-center gap-2"
              >
                <Menu size={20} />
                <ChevronDown size={16} />
              </button>
              {showDropdown && (
                <div className="absolute left-0 mt-2 w-64 bg-gray-800 rounded-lg shadow-xl z-50">
                  {Object.entries(sections).map(([key, value]) => (
                    <button
                      key={key}
                      onClick={() => {
                        setCurrentSection(key as Section);
                        setShowDropdown(false);
                      }}
                      className={cn(
                        "w-full text-right px-4 py-2 hover:bg-gray-700 transition-colors",
                        currentSection === key && "bg-blue-600"
                      )}
                    >
                      {value}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Settings Modal */}
        {showSettings && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-gray-800 p-6 rounded-lg shadow-xl w-96">
              <h2 className="text-xl font-bold mb-4">إعدادات النموذج</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm mb-2">اختر النموذج:</label>
                  <select
                    value={selectedModel.id}
                    onChange={(e) => setSelectedModel(models.find(m => m.id === e.target.value) || models[0])}
                    className="w-full bg-gray-700 rounded-lg p-2"
                  >
                    {models.map(model => (
                      <option key={model.id} value={model.id}>{model.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm mb-2">API Key:</label>
                  <div className="flex gap-2">
                    <input
                      type="password"
                      value={apiKey}
                      onChange={(e) => setApiKey(e.target.value)}
                      className="flex-1 bg-gray-700 rounded-lg p-2"
                      placeholder="أدخل API Key"
                    />
                    <button
                      onClick={saveApiKey}
                      className="bg-blue-600 hover:bg-blue-700 rounded-lg px-4"
                    >
                      <Key size={20} />
                    </button>
                  </div>
                </div>
                <button
                  onClick={() => setShowSettings(false)}
                  className="w-full bg-gray-700 hover:bg-gray-600 rounded-lg p-2 mt-4"
                >
                  إغلاق
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Chat Interface */}
        <div className="bg-gray-800 rounded-lg shadow-xl p-4 mb-4">
          <div className="h-[500px] overflow-y-auto mb-4 p-4 bg-gray-900 rounded-lg">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`mb-4 ${
                  message.role === 'user' ? 'text-left' : 'text-right'
                }`}
              >
                <div
                  className={`inline-block p-3 rounded-lg ${
                    message.role === 'user'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-700 text-white'
                  }`}
                >
                  {message.content}
                </div>
              </div>
            ))}
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="📝 اكتب سؤالك..."
              className="flex-1 bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              onClick={handleSend}
              className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg p-2 transition-colors"
            >
              <Send size={20} />
            </button>
            <button
              onClick={() => document.getElementById('file-input')?.click()}
              className="bg-gray-700 hover:bg-gray-600 text-white rounded-lg p-2 transition-colors"
            >
              <Paperclip size={20} />
            </button>
            <input
              type="file"
              id="file-input"
              className="hidden"
              onChange={(e) => {
                console.log(e.target.files?.[0]);
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;