const API_URL = 'https://openrouter.ai/api/v1/chat/completions';

export interface ModelConfig {
  id: string;
  name: string;
  model: string;
}

export const models: ModelConfig[] = [
  {
    id: 'qwen',
    name: 'Qwen Coder',
    model: 'qwen/qwen-2.5-coder-32b-instruct:free'
  },
  {
    id: 'deepseek_r1',
    name: 'Deepseek R1',
    model: 'deepseek/deepseek-r1-distill-qwen-32b:free'
  },
  {
    id: 'gemini_flash',
    name: 'Gemini Flash',
    model: 'google/gemini-2.0-flash-lite-preview-02-05:free'
  },
  {
    id: 'gemma_3',
    name: 'Gemma 3',
    model: 'google/gemma-3-4b-it:free'
  },
  {
    id: 'deepseek_chat',
    name: 'Deepseek Chat',
    model: 'deepseek/deepseek-chat:free'
  }
];

export async function sendMessage(model: string, apiKey: string, message: string) {
  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model,
        messages: [{ role: 'user', content: message }]
      })
    });

    const data = await response.json();
    return data.choices[0].message.content;
  } catch (error) {
    console.error('API error:', error);
    throw new Error('فشل في الاتصال بالخادم');
  }
}